import { useSelector } from "react-redux";

const Header = () => {
  const counter = useSelector((store) => store.counter);
  return (
    <div className="card-header">
      <div className="card-title">
        <h1 className="display-1">{counter}</h1>
      </div>
    </div>
  );
};

export default Header;
