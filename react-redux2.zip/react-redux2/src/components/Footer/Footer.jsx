const Footer = () => {
  return (
    <div className="card-footer">
      <p>React + Redux</p>
    </div>
  );
};

export default Footer;
