import { useDispatch } from "react-redux";
import { useRef } from "react";

const Body = () => {
  const dispatch = useDispatch();
  const inputRef = useRef();

  const handleIncrement = () => {
    dispatch({ type: "INC" });
  };

  const handleDecrement = () => {
    dispatch({ type: "DEC" });
  };

  const handleReset = () => {
    dispatch({ type: "RESET" });
  };

  const handleAddition = () => {
    dispatch({
      type: "ADD",
      payLoad: {
        currentVal: inputRef.current.value,
      },
    });

    inputRef.current.value = "";
  };

  const handleSubtraction = () => {
    dispatch({
      type: "SUBTRACT",
      payLoad: {
        currentVal: inputRef.current.value,
      },
    });
    inputRef.current.value = "";
  };

  return (
    <div className="card-bod py-3 px-2">
      <div className="card-text pb-3">Control the counter</div>
      <button className="btn btn-outline-danger mx-1" onClick={handleDecrement}>
        Decrease
      </button>
      <button className="btn btn-outline-secondary mx-1" onClick={handleReset}>
        Reset
      </button>
      <button
        className="btn btn-outline-success mx-1"
        onClick={handleIncrement}
      >
        Increase
      </button>
      <input
        type="text"
        className="form-control my-3"
        ref={inputRef}
        placeholder="Enter a number"
        required
      />
      <button className="btn btn-outline-warning mx-1" onClick={handleAddition}>
        Add
      </button>
      <button
        className="btn btn-outline-primary mx-1"
        onClick={handleSubtraction}
      >
        Subtract
      </button>
    </div>
  );
};

export default Body;
