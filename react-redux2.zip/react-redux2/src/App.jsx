import Body from "./components/Body/Body";
import Footer from "./components/Footer/Footer";
import Header from "./components/Header/Header";
import { Provider } from "react-redux";
import myStore from "./store/ReduxStore";

const App = () => {
  return (
    <Provider store={myStore}>
      <div className="card my-5">
        <Header />
        <Body />
        <Footer />
      </div>
    </Provider>
  );
};

export default App;
