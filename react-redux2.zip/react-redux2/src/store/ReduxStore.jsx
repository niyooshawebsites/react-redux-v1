import { createStore } from "redux";

const INITIAL_STATE = {
  counter: 0,
};
const reducer = (state = INITIAL_STATE, action) => {
  if (action.type === "INC") {
    return { counter: state.counter + 1 };
  } else if (action.type === "DEC") {
    return { counter: state.counter - 1 };
  } else if (action.type === "RESET") {
    return { counter: 0 };
  } else if (action.type === "ADD") {
    if (!isNaN(+action.payLoad.currentVal)) {
      return { counter: state.counter + +action.payLoad.currentVal };
    } else {
      alert("Pleae enter a number");
    }
  } else if (action.type === "SUBTRACT") {
    return { counter: state.counter - +action.payLoad.currentVal };
  }
  return state;
};

const myStore = createStore(reducer);

export default myStore;
